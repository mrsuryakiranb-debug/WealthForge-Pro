package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.Advisor;

public interface AdvisorRepository extends JpaRepository<Advisor, Long> {
}