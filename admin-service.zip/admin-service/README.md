# Admin Service

Spring Boot microservice for admin operations (list companies, list investors, add/delete/update company).

## Tech Stack
- Spring Boot
- Spring Data JPA
- PostgreSQL
- Spring Security (JWT, BCrypt)
- Lombok
- Validation
- Swagger
- JUnit, Mockito, JaCoCo

## How to Run
1. Configure PostgreSQL in `src/main/resources/application.properties`.
2. Build: `mvn clean install`
3. Run: `mvn spring-boot:run`

## Features
- List all companies
- List all investors
- Add, delete, update company
- JWT authentication & role-based authorization
- Exception handling & validation
- Unit tests with coverage
