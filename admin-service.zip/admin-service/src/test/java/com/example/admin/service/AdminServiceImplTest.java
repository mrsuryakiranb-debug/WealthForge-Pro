package com.example.admin.service;

import com.example.admin.dto.RegisterDTO;
import com.example.admin.entity.Admin;
import com.example.admin.entity.Role;
import com.example.admin.repository.AdminRepository;
import com.example.admin.repository.RoleRepository;
import com.example.admin.service.impl.AdminServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.Optional;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class AdminServiceImplTest {
    @Mock
    private AdminRepository adminRepository;
    @Mock
    private RoleRepository roleRepository;
    @Mock
    private PasswordEncoder passwordEncoder;
    @InjectMocks
    private AdminServiceImpl adminService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void registerAdmin_success() {
        RegisterDTO dto = new RegisterDTO();
        dto.setName("Test Admin");
        dto.setEmail("test@admin.com");
        dto.setPassword("password");
        Role role = Role.builder().id(1L).name("ROLE_ADMIN").build();
        when(roleRepository.findByName("ROLE_ADMIN")).thenReturn(Optional.of(role));
        when(passwordEncoder.encode(any())).thenReturn("encoded");
        when(adminRepository.save(any())).thenAnswer(i -> {
            Admin a = i.getArgument(0);
            a.setId(1L);
            return a;
        });
        var result = adminService.registerAdmin(dto);
        assertNotNull(result);
        assertEquals("Test Admin", result.getName());
        assertEquals("test@admin.com", result.getEmail());
        assertTrue(result.getRoles().contains("ROLE_ADMIN"));
    }
}
