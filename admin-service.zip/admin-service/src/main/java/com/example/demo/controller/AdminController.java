package com.example.demo.controller;



import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Company;
import com.example.demo.entity.Investor;
import com.example.demo.service.AdminService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

    private final AdminService service;

    public AdminController(AdminService service) {
        this.service = service;
    }

    // 15. List all companies
    @GetMapping("/companiesList")
    public List<Company> listCompanies() {
        return service.listCompanies();
    }

    // 16. List all investors
    @GetMapping("/investorsList")
    public List<Investor> listInvestors() {
        return service.listInvestors();
    }

    // 17. Add company
    @PostMapping("/add")
    public Company addCompany(@Valid @RequestBody Company company) {
        return service.addCompany(company);
    }

    @PutMapping("/update/{id}")
    public Company updateCompany(@PathVariable Long id,
                                 @Valid @RequestBody Company company) {
        return service.updateCompany(id, company);
    }

    // Delete company
    @DeleteMapping("/delete/{id}")
    public String deleteCompany(@PathVariable Long id) {
        service.deleteCompany(id);
        return "Company deleted successfully";
    }
}