package com.example.admin.controller;

import com.example.admin.dto.LoginDTO;
import com.example.admin.dto.RegisterDTO;
import com.example.admin.dto.AdminDTO;
import com.example.admin.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AdminService adminService;

    @PostMapping("/register")
    public ResponseEntity<AdminDTO> register(@RequestBody RegisterDTO registerDTO) {
        return ResponseEntity.ok(adminService.registerAdmin(registerDTO));
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO) {
        // JWT token will be returned after implementing security
        return ResponseEntity.ok(adminService.loginAdmin(loginDTO));
    }
}
