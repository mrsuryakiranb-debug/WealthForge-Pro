package com.example.admin.dto;

import lombok.Data;

@Data
public class InvestorDTO {
    private Long id;
    private String name;
    private String email;
}
