package com.example.admin.service.impl;

import com.example.admin.dto.InvestorDTO;
import com.example.admin.entity.Investor;
import com.example.admin.repository.InvestorRepository;
import com.example.admin.service.InvestorService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InvestorServiceImpl implements InvestorService {
    private final InvestorRepository investorRepository;

    @Override
    public List<InvestorDTO> getAllInvestors() {
        return investorRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    private InvestorDTO toDTO(Investor investor) {
        InvestorDTO dto = new InvestorDTO();
        dto.setId(investor.getId());
        dto.setName(investor.getName());
        dto.setEmail(investor.getEmail());
        return dto;
    }
}
