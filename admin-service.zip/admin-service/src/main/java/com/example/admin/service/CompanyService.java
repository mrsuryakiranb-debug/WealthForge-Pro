package com.example.admin.service;

import com.example.admin.dto.CompanyDTO;
import java.util.List;

public interface CompanyService {
    CompanyDTO addCompany(CompanyDTO companyDTO);
    CompanyDTO updateCompany(Long id, CompanyDTO companyDTO);
    void deleteCompany(Long id);
    List<CompanyDTO> getAllCompanies();
}
