package com.example.admin.service;

import com.example.admin.dto.InvestorDTO;
import java.util.List;

public interface InvestorService {
    List<InvestorDTO> getAllInvestors();
}
