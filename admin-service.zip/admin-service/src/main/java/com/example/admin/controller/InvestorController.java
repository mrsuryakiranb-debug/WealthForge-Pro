package com.example.admin.controller;

import com.example.admin.dto.InvestorDTO;
import com.example.admin.service.InvestorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/investors")
@RequiredArgsConstructor
public class InvestorController {
    private final InvestorService investorService;

    @GetMapping
    public ResponseEntity<List<InvestorDTO>> getAllInvestors() {
        return ResponseEntity.ok(investorService.getAllInvestors());
    }
}
