package com.example.admin.service.impl;

import com.example.admin.dto.CompanyDTO;
import com.example.admin.entity.Company;
import com.example.admin.repository.CompanyRepository;
import com.example.admin.service.CompanyService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CompanyServiceImpl implements CompanyService {
    private final CompanyRepository companyRepository;

    @Override
    public CompanyDTO addCompany(CompanyDTO companyDTO) {
        Company company = Company.builder()
                .symbol(companyDTO.getSymbol())
                .companyName(companyDTO.getCompanyName())
                .sector(companyDTO.getSector())
                .currentPrice(companyDTO.getCurrentPrice())
                .build();
        company = companyRepository.save(company);
        companyDTO.setId(company.getId());
        return companyDTO;
    }

    @Override
    public CompanyDTO updateCompany(Long id, CompanyDTO companyDTO) {
        Company company = companyRepository.findById(id).orElseThrow();
        company.setSymbol(companyDTO.getSymbol());
        company.setCompanyName(companyDTO.getCompanyName());
        company.setSector(companyDTO.getSector());
        company.setCurrentPrice(companyDTO.getCurrentPrice());
        company = companyRepository.save(company);
        companyDTO.setId(company.getId());
        return companyDTO;
    }

    @Override
    public void deleteCompany(Long id) {
        companyRepository.deleteById(id);
    }

    @Override
    public List<CompanyDTO> getAllCompanies() {
        return companyRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    private CompanyDTO toDTO(Company company) {
        CompanyDTO dto = new CompanyDTO();
        dto.setId(company.getId());
        dto.setSymbol(company.getSymbol());
        dto.setCompanyName(company.getCompanyName());
        dto.setSector(company.getSector());
        dto.setCurrentPrice(company.getCurrentPrice());
        return dto;
    }
}
