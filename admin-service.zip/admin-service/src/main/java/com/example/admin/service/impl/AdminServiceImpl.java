package com.example.admin.service.impl;

import com.example.admin.dto.AdminDTO;
import com.example.admin.dto.RegisterDTO;
import com.example.admin.dto.LoginDTO;
import com.example.admin.entity.Admin;
import com.example.admin.entity.Role;
import com.example.admin.repository.AdminRepository;
import com.example.admin.repository.RoleRepository;
import com.example.admin.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {
    private final AdminRepository adminRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public AdminDTO registerAdmin(RegisterDTO registerDTO) {
        Admin admin = Admin.builder()
                .name(registerDTO.getName())
                .email(registerDTO.getEmail())
                .password(passwordEncoder.encode(registerDTO.getPassword()))
                .roles(Set.of(roleRepository.findByName("ROLE_ADMIN").orElseThrow()))
                .build();
        admin = adminRepository.save(admin);
        AdminDTO dto = new AdminDTO();
        dto.setId(admin.getId());
        dto.setName(admin.getName());
        dto.setEmail(admin.getEmail());
        dto.setRoles(admin.getRoles().stream().map(Role::getName).collect(Collectors.toSet()));
        return dto;
    }

    @Override
    public String loginAdmin(LoginDTO loginDTO) {
        // JWT authentication logic will be implemented in security layer
        return null;
    }

    @Override
    public List<AdminDTO> getAllAdmins() {
        return adminRepository.findAll().stream().map(admin -> {
            AdminDTO dto = new AdminDTO();
            dto.setId(admin.getId());
            dto.setName(admin.getName());
            dto.setEmail(admin.getEmail());
            dto.setRoles(admin.getRoles().stream().map(Role::getName).collect(Collectors.toSet()));
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public Admin getAdminById(Long id) {
        return adminRepository.findById(id).orElseThrow();
    }
}
