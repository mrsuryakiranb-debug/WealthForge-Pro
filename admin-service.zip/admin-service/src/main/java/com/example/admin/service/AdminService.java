package com.example.admin.service;

import com.example.admin.dto.AdminDTO;
import com.example.admin.dto.RegisterDTO;
import com.example.admin.dto.LoginDTO;
import com.example.admin.entity.Admin;
import java.util.List;

public interface AdminService {
    AdminDTO registerAdmin(RegisterDTO registerDTO);
    String loginAdmin(LoginDTO loginDTO);
    List<AdminDTO> getAllAdmins();
    Admin getAdminById(Long id);
}
