package com.example.admin.dto;

import lombok.Data;

@Data
public class CompanyDTO {
    private Long id;
    private String symbol;
    private String companyName;
    private String sector;
    private Double currentPrice;
}
