package com.example.demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.entity.Investor;

@FeignClient(name = "INVESTOR-SERVICE")
public interface InvestorClient {

    @GetMapping("/investors")
    List<Investor> getAllInvestors();
}